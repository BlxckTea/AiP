package com.aip.pillowbuddy;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class FirstFragment extends Fragment {
    static final int TIME_MORNING = 0, TIME_AFTERNOON = 1, TIME_EVENING = 2, TIME_NIGHT = 3;
    private Integer[] bgIDs = {R.drawable.bg_morning, R.drawable.bg_afternoon, R.drawable.bg_evening, R.drawable.bg_night};
    private Integer[] mtIDs = {R.drawable.ff_morning_02, R.drawable.ff_afternoon_02, R.drawable.ff_evening_02, R.drawable.ff_night_02};
    private Integer[] skyIDs = {R.drawable.ff_morning_01, R.drawable.ff_afternoon_01, R.drawable.ff_evening_01, R.drawable.ff_night_01};
    private Integer[] foorIDs = {R.color.colorMorning, R.color.colorAfternoon, R.color.colorEvening, R.color.colorNight};
    private int currentBg;

    TimePicker timePicker;
    View dialogView;
    Integer tpHour, tpMinute;
    MyAlarm myAlarm = new MyAlarm(5, 30);

    private String title;
    private int page;

    //get current time
    long mNow;
    Date mDate;
    SimpleDateFormat mFormat = new SimpleDateFormat("HH");

    public static FirstFragment newInstance(int page, String title) {
        FirstFragment fragment = new FirstFragment();
        Bundle args = new Bundle();
        args.putInt("someInt", page);
        args.putString("someTitle", title);
        fragment.setArguments(args);
        return fragment;
    }

    private String getTime(){
        mNow = System.currentTimeMillis();
        mDate = new Date(mNow);
        return mFormat.format(mDate);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        page = getArguments().getInt("someInt", 0);
        title = getArguments().getString("someTitle");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_first, container, false);

        LinearLayout linearLayoutBg = (LinearLayout) view.findViewById(R.id.linear);
        LinearLayout linearLayoutFoot = (LinearLayout) view.findViewById(R.id.linearFoot);
        LinearLayout linearTvs = (LinearLayout) view.findViewById(R.id.linearTvs);
        ImageView ivSky = (ImageView) view.findViewById(R.id.ivSky);
        ImageView ivMountain = (ImageView) view.findViewById(R.id.ivMountain);
        final TextView tvFoot = (TextView) view.findViewById(R.id.tvFoot);
        final TextView tvHour = (TextView) view.findViewById(R.id.tvHour);
        final TextView tvMinute = (TextView) view.findViewById(R.id.tvMin);
        final TextView tvColon = (TextView) view.findViewById(R.id.tvColon);
        Switch switchAlarm = (Switch) view.findViewById(R.id.switchAlarm);

        //set value of currentBg
        int currentHour = Integer.parseInt(getTime()); //get hour from Device
        Toast.makeText(getContext().getApplicationContext(), getTime().toString(), Toast.LENGTH_LONG).show();
        if(currentHour >= 6 && currentHour <= 11) currentBg = TIME_MORNING;
        else if(currentHour >= 12 && currentHour <= 16) currentBg = TIME_AFTERNOON;
        else if(currentHour >= 17 && currentHour <= 19) currentBg = TIME_EVENING;
        else if((currentHour >= 20 && currentHour <=24) ||
                (currentHour >= 0 && currentHour <=5) ) currentBg = TIME_NIGHT;

//        currentBg = TIME_EVENING; //test //change bgMode

        //set resources
        linearLayoutBg.setBackgroundResource(bgIDs[currentBg]);
        linearLayoutFoot.setBackgroundResource(foorIDs[currentBg]);
        ivSky.setImageResource(skyIDs[currentBg]);
        ivMountain.setImageResource(mtIDs[currentBg]);

        //init widget
        tpHour = myAlarm.getIntHour(); //TODO get the each value from DB
        tpMinute = myAlarm.getIntMinute();
        tvHour.setText(tpHour<10? "0"+tpHour.toString(): tpHour.toString());
        tvMinute.setText(tpMinute<10? "0"+tpMinute.toString(): tpMinute.toString());
        switchAlarm.setChecked(myAlarm.isSwitchIsOn());
        if(switchAlarm.isChecked()) {
            tvFoot.setText(myAlarm.getIntHour().toString() + ":" + myAlarm.getIntMinute().toString() + "에 깨워드릴게요."); //5:30(init)
            tvHour.setTextColor(Color.WHITE);
            tvMinute.setTextColor(Color.WHITE);
            tvColon.setTextColor(Color.WHITE);
        }
        else {
            tvFoot.setText("알람이 설정되어있지 않습니다.");
            tvHour.setTextColor(Color.GRAY);
            tvMinute.setTextColor(Color.GRAY);
            tvColon.setTextColor(Color.GRAY);
        }

        //open dialog
        final View viewFromFrag = view;
        linearTvs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {
                dialogView = (View) View.inflate(getActivity(), R.layout.dialog_alarm, null);
                timePicker = (TimePicker) dialogView.findViewById(R.id.timePicker);
                AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());

                dlg.setView(dialogView);
                dlg.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        TextView tvHour = (TextView) viewFromFrag.findViewById(R.id.tvHour);
                        TextView tvMinute = (TextView) viewFromFrag.findViewById(R.id.tvMin);
                        TextView tvColon = (TextView) viewFromFrag.findViewById(R.id.tvColon);
                        Switch switchAlarm = (Switch) viewFromFrag.findViewById(R.id.switchAlarm);

                        tpHour = timePicker.getCurrentHour();
                        tpMinute = timePicker.getCurrentMinute();
                        myAlarm.setIntHour(tpHour);
                        myAlarm.setIntMinute(tpMinute);
                        myAlarm.setSwitchIsOn(true);

                        tvHour.setText(tpHour<10? "0"+tpHour.toString(): tpHour.toString());
                        tvMinute.setText(tpMinute<10? "0"+tpMinute.toString(): tpMinute.toString());
                        switchAlarm.setChecked(myAlarm.isSwitchIsOn());
                        tvHour.setTextColor(Color.WHITE);
                        tvMinute.setTextColor(Color.WHITE);
                        tvColon.setTextColor(Color.WHITE);
                        Toast.makeText(getContext().getApplicationContext(), "알람이 설정되었습니다.", Toast.LENGTH_SHORT).show();
                    }
                });
                dlg.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getContext().getApplicationContext(), "취소했습니다.", Toast.LENGTH_SHORT).show();
                    }
                });
                dlg.show();
            }
        });


        switchAlarm.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    Integer intH = myAlarm.getIntHour();
                    Integer intM = myAlarm.getIntMinute();
                    String strH = intH<10? "0"+intH.toString(): intH.toString();
                    String strM = intM<10? "0"+intM.toString(): intM.toString();
                    tvFoot.setText(strH + ":" + strM + "에 깨워드릴게요.");
                    tvHour.setTextColor(Color.WHITE);
                    tvMinute.setTextColor(Color.WHITE);
                    tvColon.setTextColor(Color.WHITE);
                    Toast.makeText(getContext().getApplicationContext(), "알람이 설정되었습니다.", Toast.LENGTH_SHORT).show();
                }
                else {
                    tvFoot.setText("알람이 설정되어있지 않습니다.");
                    tvHour.setTextColor(Color.GRAY);
                    tvMinute.setTextColor(Color.GRAY);
                    tvColon.setTextColor(Color.GRAY);
                    Toast.makeText(getContext().getApplicationContext(), "알람이 해제되었습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return view;
    }

    public int getCurrentBg() {
        return currentBg;
    }
}
